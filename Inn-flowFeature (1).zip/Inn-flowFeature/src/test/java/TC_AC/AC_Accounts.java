package TC_AC;

import org.testng.annotations.Test;
import accountingPages.Accounts;
import generics.TestBase;

public class AC_Accounts extends TestBase{

	Accounts ac;
	
	
	@Test(description = "To verify that there is a button on top left corner by which user can close & open accounting menu & it is clickable.")
	public void TC001_verifyClickabilityOfAccounting_Accounts() {
		ac=new Accounts(driver.get());
		ac.navigateOnAc();
	}
	
//	@Test(description = "To Verify when user login, it is having the Accounts Page permission then only user will have the option of Accounts page.")
//	public void TC002_verifyAcPagePermission() {
//		ac.navigationOfAccounting();
//	
//	}
	@Test(description = "To Verify EHID DD and Accounts Details with the reference of EHID ")
	public void TC002_verifyEHID_DD() {
		ac.verifyEHID_DD(tcData.get("EHID"));
		
	}
	@Test(description = "To verify that colour ,font & text of Add Accounts button should be similar to other buttons.")
	public void TC004_verifyFont_Text_colour_AddAccounts() {
		ac.verifyColour_Text_font(tcData.get("Colour"),tcData.get("FontSize"),tcData.get("Text"));
		
	}
	
	@Test(description = "To verify on clicking \"Add Accounts\" button it will open a \"Bank accounts setting\" module")
	public void TC005_verifyAddAccounts_btn_Navigation() {
		ac.navi_OnBankAcSetting(tcData.get("Bank_txt"));
	}
	
	
//	@Test(description = "")
//	public void TC006_verifyAddAccounts_btn_Navigation() {
//		
//	}
//	
	
//	
//	
//	@Test()
//	public void verifyEHIDFilter() {
//		System.out.println(Login.homePageHeader_txt.getText());
//		Assert.assertEquals(Login.homePageHeader_txt.getText(),tcData.get("hmLogo"));
//	}
//	@Test
//	public void verifyEHIDFilter1() {
//		//Assert.assertEquals(Login.homePageHeader_txt.getText(),tcData.get("hmLogo"));
//
//		//Assert.assertEquals(false, true);
//	}
//	@Test
//	public void verifyEHIDFilter2() {
//		//Assert.assertEquals(Login.homePageHeader_txt.getText(),tcData.get("hmLogo"));
//
//	}
	
	
}

package TC_AC;

import org.testng.Assert;
import org.testng.annotations.Test;

import generics.TestBase;

public class AC_Register extends TestBase{
	@Test
	public void verifyEHIDFilter() {
		
	}
	@Test
	public void verifyEHIDFilter1() {
		//Assert.assertEquals(false, true);
	}
	@Test
	public void verifyEHIDFilter2() {
		
	}
}

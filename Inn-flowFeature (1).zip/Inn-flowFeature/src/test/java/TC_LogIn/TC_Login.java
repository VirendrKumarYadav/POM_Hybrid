package TC_LogIn;

import org.testng.annotations.Test;

import generics.TestBase;

public class TC_Login extends TestBase {

	@Test
	public void TC001ValidLogin() {
		loginPage.validLogin(tcData.get("username"), tcData.get("password"));
	}
     @Test
	public void  TC002LoginWithPass() {
		loginPage.invalidLogin_withPass(tcData.get("username"), tcData.get("password"));
	}
	
	@Test
	public void  TC003LoginWith_InvalidUser() {
		loginPage.invalidLogin_WithUname(tcData.get("username"), tcData.get("password"));
	}
	
	@Test
	public void  TC004LoginWith_InActiveUser() {
		loginPage.inactive(tcData.get("username"), tcData.get("password"));
	}
}

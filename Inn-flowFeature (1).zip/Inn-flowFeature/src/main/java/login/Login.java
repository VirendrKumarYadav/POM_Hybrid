package login;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import generics.TestBase;
import generics.WaitStatement;

public class Login extends TestBase {

	ThreadLocal<WebDriver> driver;

	public Login(ThreadLocal<WebDriver> driver) {
		this.driver = driver;
		PageFactory.initElements(driver.get(), Login.this);
	}

	String homepg_txt = "Home";

	@FindBy(xpath = "//input[@id='formBasicEmail']")private WebElement username_in;
	@FindBy(xpath = "//input[@id='formBasicPassword']")private WebElement passwor_in;
	@FindBy(xpath = "//button[normalize-space()='Login']")private WebElement login_btn;
	@FindBy(xpath = "//div[@class='mr-auto align-items-center']")public static WebElement homePageHeader_txt;
	@FindBy(xpath = "//div[@class='arrow']")public static WebElement logOut_arrow;
	@FindBy(xpath = "//a[@id='Logout']")public static WebElement logOut_btn;
    @FindBy(xpath="//a[@id='defaultSet-Home']//div[@class='d-flex justify-content-start align-items-center']") public static WebElement home_btn;
	/*************************************************************************************************************/

	public void Inn_flow_Login(String uName, String uPass) {
		username_in.clear();
		username_in.sendKeys(uName);
		passwor_in.clear();
		passwor_in.sendKeys(uPass);
		login_btn.click();
		try {
			WaitStatement.eWaitForVisible(20, homePageHeader_txt);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (homePageHeader_txt.getText().equals(homepg_txt)) {
			logger.info("Inn-Flow Login Successfully");
		} else {
			logger.assertLog(false, "Inn-FLow is not landing on Home Page");
		}
		
		
	}

	public void validLogin(String uName, String uPass) {
		logOut();
		username_in.clear();
		username_in.sendKeys(uName);
		passwor_in.clear();
		passwor_in.sendKeys(uPass);
		login_btn.click();
		logOut();
	}

	public void invalidLogin_withPass(String uName, String uPass) {
		username_in.clear();
		username_in.sendKeys(uName);
		passwor_in.clear();
		passwor_in.sendKeys(uPass);
		login_btn.click();
	
	}

	public void inactive(String uName, String uPass) {
		username_in.clear();
		username_in.sendKeys(uName);
		passwor_in.clear();
		passwor_in.sendKeys(uPass);
		login_btn.click();
		
	}

	public void invalidLogin_WithUname(String uName, String uPass) {
		username_in.clear();
		username_in.sendKeys(uName);
		passwor_in.clear();
		passwor_in.sendKeys(uPass);
		login_btn.click();

	}

	public void logOut() {
		logOut_arrow.click();
		logOut_btn.click();
		try {
			WaitStatement.eWaitForVisible(20, username_in);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

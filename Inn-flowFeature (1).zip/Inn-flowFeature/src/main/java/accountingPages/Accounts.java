package accountingPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import generics.Innflow_Util;
import generics.TestBase;
import generics.WaitStatement;

public class Accounts extends TestBase{
	Innflow_Util iu;
	
	public Accounts(WebDriver driver) {
		PageFactory.initElements(driver, Accounts.this);
		iu=new Innflow_Util(driver);
	}
	
	@FindBy(xpath="//div[@class='lable mr-auto'][normalize-space()='Accounting']")private WebElement accounting_btn;
	@FindBy(xpath="//div[@class='ellipsis'][normalize-space()='Accounts']")private WebElement accounts_btn;
	@FindBy(xpath="")private WebElement EHID_btn;
	@FindBy(xpath="//div[@class='d-flex align-items-center justify-content-center']")private WebElement EHID_DD;
	@FindBy(xpath="//button[normalize-space()='Add Account']")private WebElement addAccounts_btn;
	@FindBy(xpath="//div[@class='mr-auto d-flex align-items-center']")private WebElement bank_ac_setting_txt;
	
	
	
	
	public void navigateOnAc() {
		try {
			WaitStatement.eWaitForVisible(20, accounting_btn);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		accounting_btn.click();
		accounts_btn.click();
		
		try {
			WaitStatement.eWaitForVisible(20, iu.EHID_dd);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void verifyEHID_DD(String EHID ) {
		iu.clickOnEHID_ByEHID(EHID);
	}
	
	public void verifyColour_Text_font(String clr,String font_sz,String expText) {
		try {
			WaitStatement.eWaitForVisible(20, addAccounts_btn);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		iu.verifyColour(addAccounts_btn, clr);
		iu.verifyFontSize(addAccounts_btn, font_sz);
		iu.verifyText(addAccounts_btn, expText);
	}
	
	public void navi_OnBankAcSetting(String expTxt) {
		addAccounts_btn.click();
		try {
			WaitStatement.eWaitForVisible(20, bank_ac_setting_txt);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		iu.verifyText(bank_ac_setting_txt, expTxt);
	}
}

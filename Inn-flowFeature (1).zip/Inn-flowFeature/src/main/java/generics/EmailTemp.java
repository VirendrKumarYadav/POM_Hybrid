package generics;

import java.io.File;
import java.util.Date;
import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.NoSuchProviderException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.aeonbits.owner.ConfigFactory;

public class EmailTemp extends TestBase {

	static Environment configENV = ConfigFactory.create(Environment.class);

	static String fileName = System.getProperty("user.dir") + "\\Reports\\Inn_Flow_ExtentReports.html";

	public static void main(String className) {
		String d = CommonUtil.getCurrentDate_MM_dd_yy();
		String message = "Hello Team !\nThis is Inn-Flow Automation Test Reports:" + className
				+ "\nNew Build is triggered!,Attatched html file contains '" + className
				+ "' feature test cases result status. Date:" + d
				+ "\n\nPlease download this report then open in browser for better viewing.";
		String subject = "Inn-Flow (Automation Report) : " + className + "__" + d;

		String from = "Virendra_Kumar_Yadav";
		String to = configENV.To();
		String To[] = to.split(",");
		sendMail(message, subject, To, from, fileName);

	}

	public void main(String className, String data) {
		String d = CommonUtil.getCurrentDate_MM_dd_yy();
		String message = "Hello Team !\nThis is Inn-Flow Automation Test Reports:-" + className
				+ " Auto-Generate Invoice No.[" + data + "]"
				+ "\nNew Build is triggered!,Attatched html file contains '" + className
				+ "' feature test cases result status. Date:" + d
				+ "\n\nPlease download this report then open in browser for better viewing.";
		String subject = "Inn-Flow (Automation Report) : " + className + "__" + d;

		String from = "Virendra_Kumar_Yadav";

		// to[]={"jyoti.rajpal@inn-flow.com","avinash.dubey@inn-flow.com","Virendra.Yadav@inn-flow.com"};
		String to = configENV.To();
		String To[] = to.split(",");

		sendMail(message, subject, To, from, fileName);
		// outlookEmail(message, subject, to, from);
	}

	public void SendMailToByAttetchReport(String userEmail, String reportName) {
		String d = CommonUtil.getCurrentDate_MM_dd_yy();
		String message = "Hello Team !\nThis is Inn-Flow Automation Test Reports:" + reportName
				+ "\nNew Build is triggered!,Attatched html file contains '" + reportName
				+ "' feature test cases result status. Date:" + d
				+ "\n\nPlease download this report then open in browser for better viewing.";
		String subject = "Inn-Flow (Automation Report) : " + reportName + "__" + d;

		String from = "Virendra_Kumar_Yadav";

		String to[] = { userEmail, "innflow.auto0011@gmail.com" };
		String file = "C:\\Users\\virendra.y\\InnflowAutomation\\src\\main\\resources\\WorkBooks\\03-10-22 to 04-09-22.pdf";

		sendMail(message, subject, to, from, file);

	}

	public static void sendMail(String message, String subject, String to[], String from, String filename) {
		String host = "smtp.gmail.com";

		Properties properties = System.getProperties();
		System.out.println("PROPERTIES" + properties);
		properties.put("mail.smtp.host", host);
		properties.put("mail.smtp.port", "465");
		properties.put("mail.smtp.ssl.enable", "true");
		properties.put("mail.smtp.auth", "true");
		properties.put("mail.smtp.starttls.enable", true);
		properties.put("mail.debug", "true");
		properties.put("mail.smtp.socketFactory.port", 587);
		// props.put("mail.smtp.socketFactory.class","javax.net.ssl.SSLSocketFactory");
		properties.put("mail.smtp.socketFactory.fallback", "false");
		properties.put("mail.smtp.ssl.trust", host);

		Session session = Session.getInstance(properties, new Authenticator() {

			@Override
			protected PasswordAuthentication getPasswordAuthentication() {

				return new PasswordAuthentication(configENV.gmail_Username(), configENV.gmailPassword());
			}

		});
		session.setDebug(true);// this to print data on console
		MimeMessage m = new MimeMessage(session);
		try {
			m.setFrom(from);
			m.setHeader("Emp.", "Virendra Kumar Yadav ");
			for (String reciver : to)
				m.addRecipient(Message.RecipientType.BCC, new InternetAddress(reciver, "Virendra Kumar Yadav"));
			m.setSubject(subject);
			m.setText(message);
			Date dt = new Date();
			String d = dt.toString().replace(":", "_").replace(" ", "_");
			m.setText("date", d);

			// m.setFileName(fileName);
			MimeBodyPart attachment = new MimeBodyPart();
			MimeBodyPart text = new MimeBodyPart();

			File file = new File(filename);
			attachment.attachFile(file);
			text.setText(message);
			// Set the actual message of the Email:

			Multipart mp = new MimeMultipart();
			mp.addBodyPart(text);
			mp.addBodyPart(attachment);
			m.setContent(mp);

			Transport.send(m);

			// Transport.send(m, "virendra.y", "Wjq6AJKvyg");

			System.out.println("..................... Mail  Sent  Success .......................!");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void outlookEmail(String message, String subject, String to[], String from) {
		String host = "outlook.office365.com";
		Properties properties = System.getProperties();
		System.out.println("PROPERTIES" + properties);

		properties.put("mail.smtp.auth", "true");
		properties.put("mail.smtp.starttls.enable", "true");
		properties.put("mail.smtp.host", host);
		properties.put("mail.smtp.port", 587);

		properties.put("mail.smtp.starttls.enable", true);
		properties.put("mail.smtp.socketFactory.port", properties);
		// props.put("mail.smtp.socketFactory.class","javax.net.ssl.SSLSocketFactory");
		properties.put("mail.smtp.socketFactory.fallback", "false");
		properties.put("mail.smtp.ssl.trust", host);

		Session session = Session.getInstance(properties, new Authenticator() {

			@Override
			protected PasswordAuthentication getPasswordAuthentication() {

				return new PasswordAuthentication("Virendra.Yadav@inn-flow.com", "Suraj.if0011@");

			}

		});
		session.setDebug(true);
		MimeMessage m = new MimeMessage(session);

		try {
			m.setFrom(from);
			m.setHeader("Emp.", "Virendra");
			for (String reciver : to)
				m.addRecipient(Message.RecipientType.BCC, new InternetAddress(reciver, "Virendra Kumar Yadav"));
			m.setSubject(subject);
			m.setText(message);
			Date dt = new Date();
			String d = dt.toString().replace(":", "_").replace(" ", "_");
			m.setText("date", d);

			// m.setFileName(fileName);
			MimeBodyPart attachment = new MimeBodyPart();
			MimeBodyPart text = new MimeBodyPart();

			File file = new File(fileName);
			attachment.attachFile(file);
			text.setText(message);
			// Set the actual message of the Email:

			Multipart mp = new MimeMultipart();
			mp.addBodyPart(text);
			mp.addBodyPart(attachment);
			m.setContent(mp);

			Transport.send(m);

			System.out.println(".....................  Sent  Success .......................!");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static void check(String host, String storeType, String user, String password) {
		try {

			// create properties field
			Properties properties = new Properties();

			properties.put("mail.pop3.host", host);
			properties.put("mail.pop3.port", "995");
			properties.put("mail.pop3.starttls.enable", "true");
			Session emailSession = Session.getDefaultInstance(properties);

			// create the POP3 store object and connect with the pop server
			Store store = emailSession.getStore("pop3s");

			store.connect(host, user, password);

			// create the folder object and open it
			Folder emailFolder = store.getFolder("INBOX");
			emailFolder.open(Folder.READ_ONLY);

			// retrieve the messages from the folder in an array and print it
			Message[] messages = emailFolder.getMessages();
			System.out.println("messages.length---" + messages.length);

			for (int i = 0, n = messages.length; i < n; i++) {
				Message message = messages[i];
				System.out.println("---------------------------------");
				System.out.println("Email Number " + (i + 1));
				System.out.println("Subject: " + message.getSubject());
				System.out.println("From: " + message.getFrom()[0]);
				System.out.println("Text: " + message.getContent().toString());
				System.out.println("Text: " + message.getContent().toString());
			}

			// close the store and folder objects
			emailFolder.close(false);
			store.close();

		} catch (NoSuchProviderException e) {
			e.printStackTrace();
		} catch (MessagingException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {

		String host = "pop.gmail.com";// change accordingly
		String mailStoreType = "pop3";
		String username = "innflow.auto0011@gmail.com";// change accordingly
		String password = "diqriwffmccspfdj";// change accordingly
		check(host, mailStoreType, username, password);

	}
}

package generics;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Test;

public class ExcelUtils extends TestBase{

	static Workbook wbook;
	Sheet sheetObj;
	InputStream fi;
	OutputStream fo;
	Row rowObj;
	Cell cellObj;
	Map<String, String> mapObj = new HashMap<String, String>();
/***************************** Excel Method********************************/
	public static Workbook getWorkBook(String dataSheetPath) {
		File xlFile = new File(dataSheetPath);
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(xlFile);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String[] arrPath = dataSheetPath.split("\\.");
		String fileExt = arrPath[1];
		if ("xlsx".equalsIgnoreCase(fileExt)) {
			try {
				wbook = new XSSFWorkbook(fis);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			try {
				wbook = new HSSFWorkbook(fis);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return wbook;
	}

	// ================ SheetObj ===============//
	public Sheet getSheetObj(Workbook workBook, String sheetName) {

		sheetObj = workBook.getSheet(sheetName);
		return sheetObj;
	}

	public Row getRowObj(Sheet sheetObj, int rowNum) {
		rowObj = sheetObj.getRow(rowNum);
		return rowObj;
	}

	public String getCellData(Row dataRow, int cellNum) {
		DataFormatter df = new DataFormatter();
		Cell curCell = dataRow.getCell(cellNum, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
		return df.formatCellValue(curCell);

	}

	// =====================================================================================================//
	public int getColumnNumberByColumnName(Sheet sheet, String columnName,String startRowName) {
		int startRowNum = getRowNumByName(wbook, sheetObj, startRowName);
		Row firstRowColumns = sheet.getRow(startRowNum);
		int columnNumber = -1;
		int columnCount = firstRowColumns.getLastCellNum();
		for (int i = 0; i <= columnCount - 1; i++) {

			if (firstRowColumns.getCell(i).getStringCellValue().toLowerCase().contains(columnName.toLowerCase())) {
				columnNumber = i;
				break;
			}
		}
		return columnNumber;
	}

	public int getColumnNumberByColumnNameByRow(Row firstRowColumns, String columnName) {
		int columnNumber = -1;
		int columnCount = firstRowColumns.getLastCellNum();
		for (int i = 0; i <= columnCount - 1; i++) {

			if (firstRowColumns.getCell(i).getStringCellValue().toLowerCase().contains(columnName.toLowerCase())) {
				columnNumber = i;
				break;
			}
		}
		return columnNumber;
	}

	// ============================================================================================//
	public int getRowNumberByRowID(Sheet sheet, String rowID, String columnName,String startRowName) {
		int rowCount = sheet.getLastRowNum();
		int columnNumber = getColumnNumberByColumnName(sheet, columnName,startRowName);
		int rowNumber = -1;
		int startCellNum = getRowNumByName(wbook, sheetObj,startRowName);
		for (int i = startCellNum; i <= rowCount; i++) {
			rowObj = sheet.getRow(i);
			if (rowObj != null) {
				Cell cell = rowObj.getCell(columnNumber, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);

				if (cell != null && cell.getStringCellValue().contains(rowID)) {
					rowNumber = i;
					break;
				}
			}
		}
		return rowNumber;
	}

	public int getRowNumByName(Workbook wbObj, Sheet sheetObj, String cellName) {
		int rowNum = 0;
		int lastRow = sheetObj.getLastRowNum();
		for (int i = 0; i < lastRow; i++) {
			Row FirstColumn = getRowObj(sheetObj, i);
			if (FirstColumn == null) {
				continue;
			} else {
				String data = getCellData(FirstColumn, 0);
				if (cellName.equalsIgnoreCase(data)) {
					rowNum = i;
					break;
				}
			}

		}
		return rowNum;
	}
	public int getLastActiveRowNumWithTag(Workbook wbObj, Sheet sheetObj, String cellName) {
		int lastRow = sheetObj.getLastRowNum();
		int startRowNum = getRowNumByName(wbObj, sheetObj, cellName);
		for (int i = startRowNum; i <= lastRow; i++) {
			Row row = sheetObj.getRow(i);
			if (row == null) {
				lastRow = i;
				break;
			}
			String FirstColumn = row.getCell(0).getStringCellValue();
			if (FirstColumn == null || FirstColumn.equals("")) {
				lastRow = i;
				break;
			} else {

			}

		}
		return lastRow;

	}
	/***********************************Get load TC Wise data *********************************************/
	
	public  Map<String, String> getDataFromExcelFromTestCase(String path, String sheetname, String rowName,
			String colnmName,String startRowName) {
		int dataRowNum;

		Workbook wbook = getWorkBook(path);
		sheetObj = getSheetObj(wbook, sheetname);
		
		dataRowNum = getRowNumberByRowID(sheetObj, rowName, colnmName,startRowName);
		
		for (int i = 1; i <=1; i++) {
			Row rowObj = sheetObj.getRow(dataRowNum);
			if (rowObj == null) {
				break;
			}
			int clmNum = getColumnNumberByColumnName(sheetObj, colnmName,startRowName);

			dataRowNum++;
			for (int j = clmNum + 1; j < clmNum + 2; j = j + 2) {

				Cell cellObj = rowObj.getCell(j);
				if (cellObj == null) {
					break;
				}
				String cellKey = cellObj.getStringCellValue();
				String [] keys=getListOfKey(cellKey);
				String cellValue = rowObj.getCell(j + 1).getStringCellValue();
				String [] values=getListOfValue(cellValue);
				for(int noOfKey=0; noOfKey<keys.length;noOfKey++) {
				       try {
					    mapObj.put(keys[noOfKey].trim(), values[noOfKey].trim());
				       }catch (Exception e) {
					   logger.error("Pls update the details Of Key==Value Pair in TC sheet ");
					}
				}
			}
		}
		return mapObj;

	}
	
	
	public  Map<String, String> getLoginDetailsFromSheet(String path, String sheetname, String startRowName) {
	

		Workbook wbook = getWorkBook(path);
		sheetObj = getSheetObj(wbook, sheetname);
		
		int firstRowNo = getRowNumByName(wbook,sheetObj ,startRowName);
		int lastCellNum=getLastActiveRowNumWithTag(wbook, sheetObj, startRowName);
		
		for (int i = firstRowNo; i <lastCellNum; i++) {
			Row rowObj = sheetObj.getRow(i);
			if (rowObj == null) {
				break;
			}
			

			for (int j = 0; j < 2 ; j = j + 2) {
				Cell cellObj = rowObj.getCell(j);
				if (cellObj == null) {
					break;
				}
				
				String cellDataName = cellObj.getStringCellValue();
				String cellDataValue = rowObj.getCell(j + 1).getStringCellValue();
				
				mapObj.put(cellDataName, cellDataValue);
			}
		}
		return mapObj;

	}
	/********************************************************************************************/
	
	
	public static void main(String[] args) {
		
		Map<String,String> mapData=new ExcelUtils().getDataFromExcelFromTestCase("src/test/resources/Inn-Flow_Feature.xlsx", "AC_Accounts",
				"verifyEHIDFilter", "TestCaseID","TCNo.");
		System.out.println(mapData);
//		
//		Map<String,String> mapDat1=new ExcelUtils().getLoginDetailsFromSheet("src/test/resources/Inn-Flow_Feature.xlsx", "AC_Accounts","Module");
//		System.out.println(mapDat1);
		
//		String str="hmLogo,\r\n"
//				+ "username,\r\n"
//				+ "password,";
//		String arr[]=str.split("\\=");
//		System.out.println(getListOfValue();
	}
	private static  String []  getListOfKey(String keys) {
		String arr[]=keys.split("\\=");
		
		return arr;
	}
	private static String []  getListOfValue(String keys) {
		String arr[]=keys.split("\\,");
		return arr;
	}
	
	
	
/**********************************************************************************************/
/*********************************************************************************************/	
	// --------------create Run Time XML -----------------------//
	
	Cell cellObjTestcaseID;
	Workbook workbook;
	String cellDataTestcaseID, cellData;
	Set<String> testcaseID = new HashSet<String>();

	@Test
	public Set<String> tain(String testCaseName) {
		// Path of the excel file
		FileInputStream fs;

		try {
			fs = new FileInputStream("src/test/resources/Inn-Flow_Feature.xlsx");
			workbook = new XSSFWorkbook(fs);// --xlsx
			// workbook = new HSSFWorkbook(fs); //-- xls
		} catch (IOException e) {
			e.printStackTrace();
		}
		// Sheet sheet = workbook.getSheetAt(0);
		sheetObj = workbook.getSheet(testCaseName);

		int lastRow = sheetObj.getLastRowNum();
	  int colNum=getColumnNumberByColumnName(sheetObj, "RunStatus","TCNo.");
		for (int i = 1; i <= lastRow; i++) {
			rowObj = sheetObj.getRow(i);
			if(rowObj==null)
				continue;
			
			cellObj = rowObj.getCell(colNum);
			if(cellObj==null) {
				continue;
			}else {
			cellData = cellObj.getStringCellValue();

			if (cellData.equalsIgnoreCase("YES")) {
				// System.out.println(cellData);
				rowObj = sheetObj.getRow(i);
				 cellObjTestcaseID = rowObj.getCell(colNum-3);
				cellDataTestcaseID = cellObjTestcaseID.getStringCellValue();
				// System.out.println(cellDataTestcaseID);
				testcaseID.add(cellDataTestcaseID);
			}

		}
		}
		return testcaseID;
	}

	public Set<String> getColoumName(String sheetName) {
		Set<String> cellData = new HashSet<String>();
		sheetObj = workbook.getSheet(sheetName);
		rowObj = sheetObj.getRow(0);
		short lastCellNum = rowObj.getLastCellNum();
		for (int i = 0; i < lastCellNum; i++) {
			cellObj = rowObj.getCell(i);
			String cellDatavalue = cellObj.getStringCellValue();
			cellData.add(cellDatavalue);

		}
		return cellData;
	}

	public int getColumnNumberByColumnName(Sheet sheet, String columnName) {
		Row firstRowColumns = sheet.getRow(0);
		int columnNumber = -1;
		int columnCount = firstRowColumns.getLastCellNum();
		for (int i = 0; i <= columnCount - 1; i++) {
			
			if (firstRowColumns.getCell(i).getStringCellValue().toLowerCase().contains(columnName.toLowerCase())) {
				columnNumber = i;
				break;
			}
		}
		return columnNumber;
	}
	
//================================================================================================//	
	
	
	
	
	
	
	
}


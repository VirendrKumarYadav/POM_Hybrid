package generics;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * 
 * 
 * @author virendra
 *
 */
public class WaitStatement extends TestBase {
	
	public WaitStatement(ThreadLocal<WebDriver> driver)//constructor
	{
		this.driver=driver;
		
	}
	
	/*************hardcore method
	 * @return *************/
	public static void holdOn(int secs)//hardcore method
	{
		try{
		Thread.sleep(secs*1000);
		}
		catch(InterruptedException e)
		{
			e.printStackTrace();
		}
		
	}
	/*************IMPLICIT Wait*************/
	public static void iWaitForSecs(int secs)//IMPLICIT Wait
	{
		driver.get().manage().timeouts().implicitlyWait(secs, TimeUnit.SECONDS);
		
	}
	
	/*************Explicit Wait
	 * @throws Exception *************/
	public static void eWaitForVisible(int secs, WebElement ele) throws Exception
	{
		try{
		WebDriverWait wait=new WebDriverWait(driver.get(),secs);
		wait.ignoring(StaleElementReferenceException.class);
		wait.until(ExpectedConditions.visibilityOf(ele));
		}catch (Exception e) {
			
			throw new Exception("WaitStatement :: waitUntilElementOfGivenXPathIsVisible()::Exception : " + e.getLocalizedMessage());		
		}
	}
	
	public static void waitUntilElementOfGivenXPathIsVisible(int secs, WebElement ele) throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait((WebDriver) driver, secs);
			wait.until(ExpectedConditions.visibilityOfElementLocated((By) ele));
		} catch (Exception e) {
			throw new Exception("WaitStatement :: waitUntilElementOfGivenXPathIsVisible()::Exception : " + e.getLocalizedMessage());
		}
	}
	
	/*************Refresh*************/
	public  static void eRefresh(int secs, WebElement ele)
	{
		WebDriverWait wait=new WebDriverWait(driver.get(),secs);
		wait.until(ExpectedConditions.refreshed(ExpectedConditions.visibilityOf(ele)));
	}
}

	package generics;

import org.aeonbits.owner.ConfigFactory;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SeleniumActions extends TestBase{
	
Environment configENV = ConfigFactory.create(Environment.class);
	
	public SeleniumActions(ThreadLocal<WebDriver> driver) {

		PageFactory.initElements(driver.get(), this);
	}
	
	
//	public static void clickOnWebElement(WebDriver driver, WebElement element) throws Exception {
//		try {
//			WebDriverWait wait = new WebDriverWait(driver, 10);
//			wait.until(ExpectedConditions.elementToBeClickable(element));
//			element.click();
//		} catch (Exception e) {
//			throw new Exception("SeleniumActions :: clickOnWebElement()::Exception : " + e.getLocalizedMessage());
//		}
//	}
	
	
	
	public static void doubleClickOnWebElement(WebElement targetElement) throws Exception {
		try {
			Actions builder = new Actions(driver.get());
			WebDriverWait wait = new WebDriverWait(driver.get(), 10);
			wait.until(ExpectedConditions.elementToBeClickable(targetElement));
			builder.doubleClick(targetElement).build().perform();

		} catch (Exception e) {
			throw new Exception("SeleniumActions :: doubleClickOnWebElement()::Exception : " + e.getLocalizedMessage());
		}
	}


	public static void doubleClickOnCurrentLocation() throws Exception {
		try {
			Actions builder = new Actions(driver.get());

			builder.doubleClick().build().perform();

		} catch (Exception e) {
			throw new Exception("SeleniumActions :: doubleClickOnCurrentLocation()::Exception : " + e.getLocalizedMessage());
		}
	}


	public static void clickOnCurrentCursorLocation() throws Exception {
		try {
			Actions builder = new Actions(driver.get());

			Action clickAction;

			clickAction = builder.click().build();

			clickAction.perform();
		} catch (Exception e) {
			throw new Exception("SeleniumActions :: clickOnCurrentCursorLocation()::Exception : " + e.getLocalizedMessage());
		}
	}

	

	public static void contextClickAtCurrentLocation() throws Exception {
		try {
			Actions builder = new Actions(driver.get());

			Action clickAction;

			clickAction = builder.contextClick().build();

			clickAction.perform();
		} catch (Exception e) {
			throw new Exception("SeleniumActions :: contextClickAtCurrentLocation()::Exception : " + e.getLocalizedMessage());
		}
	}

	public static void moveToWebElement(WebElement webElement) throws Exception {
		try {
			Actions builder = new Actions(driver.get());

			Action moveAction;

			moveAction = builder.moveToElement(webElement).build();

			moveAction.perform();
		} catch (Exception e) {
			throw new Exception("SeleniumActions :: moveToWebElement()::Exception : " + e.getLocalizedMessage());
		}
	}

	

	public static void performCtrlClickAtCurrentLocation() {
		Actions builder = new Actions(driver.get());
		builder.keyDown(Keys.CONTROL).click().keyUp(Keys.CONTROL).build().perform();
	}
 

	public static void pressGivenKey(Keys key) throws Exception {
		try {
			if(key!=null) {				
				Actions builder = new Actions(driver.get());
				builder.sendKeys(key).build().perform();
			}else
				throw new Exception("Key not provided");
		} catch (Exception e) {
			throw new Exception("SeleniumActions :: pressGivenKey()::Exception : " + e.getLocalizedMessage());
		}
	}
	
	public static void enterTextInTextBox(String coordinateValue) throws Exception
	{		try {
		Actions builder=new Actions(driver.get());
		builder.sendKeys(coordinateValue).build().perform();
	}   catch (Exception e) {
		throw new Exception("SeleniumActions :: enterTextInTextBox()::Exception : " + e.getLocalizedMessage());
	}
	}
	

	public static void ctrlPlusClickOnWebElement(WebElement element) throws Exception {
		try {
			if(element!=null) {
				WebDriverWait wait = new WebDriverWait(driver.get(), 10);
				wait.until(ExpectedConditions.elementToBeClickable(element));
				Actions actions = new Actions(driver.get());
				actions.keyDown(Keys.CONTROL).click(element).keyUp(Keys.CONTROL).build().perform();
			}
			else
				throw new Exception("Element for ctrl+click is null");
		} catch (Exception e) {
			throw new Exception("SeleniumActions :: ctrlPlusClickOnWebElement()::Exception : " + e.getLocalizedMessage());
		}
	}
	
	public static void waitUntilElementVisibility(WebElement element) throws Exception {
		try {
		WebDriverWait wait = new WebDriverWait(driver.get(), 10);
		wait.until(ExpectedConditions.visibilityOf(element));
		} catch (Exception e) {
		throw new Exception("SeleniumActions :: waitUntilElementVisibility()::Exception : " + e.getLocalizedMessage());
		}
		}

}

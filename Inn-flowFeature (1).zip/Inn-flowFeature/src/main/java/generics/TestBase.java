package generics;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import io.github.bonigarcia.wdm.WebDriverManager;
import login.Login;

import java.io.File;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.aeonbits.owner.ConfigFactory;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class TestBase {

	public static ThreadLocal<WebDriver> driver = new ThreadLocal<WebDriver>();
	public static ExtentReports extent;
	public ExtentTest test;
	public ExtentSparkReporter reporter;
	public Map<String, String>tcData;

	public static final Logger logger = Logger.getLogger(TestBase.class);
	public static Login loginPage ;
	@BeforeSuite
	public void beforesuitsetup() {
		
		File log4jfile = new File("log4j/log4j.properties");
		PropertyConfigurator.configure(log4jfile.getAbsolutePath());
		
		ConfigFactory.setProperty("env", CommonUtil.getPropVal("env"));
		Environment configENV = ConfigFactory.create(Environment.class);
		reporter = new ExtentSparkReporter(System.getProperty("user.dir") + "/Reports/Inn_Flow_ExtentReports.html");
		reporter.config().setDocumentTitle("Extent Report Demo");
		reporter.config().setReportName("Virendra Yadav");
		reporter.config().setTheme(Theme.DARK);
		reporter.config().setTimeStampFormat("EEEE, MMMM dd, yyyy, hh:mm a '('zzz')'");
		extent = new ExtentReports();
		extent.attachReporter(reporter);
		extent.setSystemInfo("Environment", configENV.url());
		extent.setSystemInfo("Browser", "Chrome");
		extent.setSystemInfo("Emp Name", "Virendra");
	}

	@BeforeTest(alwaysRun = true)
	public void before_test_setup(ITestContext result) throws Exception {
		Environment configENV = ConfigFactory.create(Environment.class);
		ConfigFactory.setProperty("env", CommonUtil.getPropVal("env"));

		String ScriptName = result.getName().toString();
        tcData= new ExcelUtils().getLoginDetailsFromSheet(configENV.TC_SheetPath(), ScriptName, "Module");
       
		WebDriverManager.chromedriver().setup();
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--disable-dev-shm-usage"); /** overcome limited resource problems **/
		options.addArguments("start-maximized"); /** open Browser in maximized mode **/
		options.addArguments("disable-infobars"); /** disabling infobars **/
		options.addArguments("--disable-extensions"); /** disabling extensions **/
		options.addArguments("--no-sandbox"); /** Bypass OS security model **/
		driver.set(new ChromeDriver(options));
		Reporter.log("Chrome launched", true);
		logger.info("Chrome Launched ");
		driver.get().manage().window().maximize();
		WaitStatement.holdOn(2);
        
		try {
			driver.get().manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			driver.get().get(configENV.url());
		} catch (Exception e) {
			e.printStackTrace();
		}
		 loginPage = new Login(driver);
		try {
			if(tcData.get("uName").equals("")) {
				loginPage.Inn_flow_Login(configENV.username(), configENV.password());
			}else {
				loginPage.Inn_flow_Login(tcData.get("uName"), tcData.get("uPass"));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}

		logger.info("--------------- Script Running-----------");

	}

	@BeforeMethod
	public void beforetestsetup(Method method) {
		Environment configENV = ConfigFactory.create(Environment.class);
		ConfigFactory.setProperty("env", CommonUtil.getPropVal("env"));

		String methodname = method.getName();
		String[] clsName = super.getClass().toString().split(" ");
		String clasName[] = clsName[1].split("\\.", 2);
		test = extent.createTest(clasName[1]+"##"+methodname);
		logger.info(clasName[1]+":"+methodname);
        tcData= new ExcelUtils().getDataFromExcelFromTestCase(configENV.TC_SheetPath(), clasName[1],
        		methodname, "TestCaseID","TCNo.");;
	}

	@AfterMethod
	public void aftertestsetup(ITestResult result) throws Exception {
		String ScriptName = result.getMethod().getMethodName();

		if (ITestResult.FAILURE == result.getStatus()) {

			test.fail("This Test Case FAILED: ", MediaEntityBuilder
					.createScreenCaptureFromBase64String(ScreenshotLib.getScreenshotExtent(driver.get())).build());
			test.fail(MarkupHelper.createLabel("Test Case " + ScriptName + " Status is FAILED:", ExtentColor.RED));
			logger.info(ScriptName + " Script is failed and Screenshot has been taken:");

			Reporter.log(ScriptName + " Script is failed and Screenshot has been taken:", true);

			String excepionMessage = result.getThrowable() + Arrays.toString(result.getThrowable().getStackTrace());
			test.fail("<details>" + "<summary>" + "<b>" + "<font color=" + "red>" + "Exception Occured:Click to see"
					+ "</font>" + "</b >" + "</summary>" + excepionMessage.replaceAll(",", "<br>") + "</details>"
					+ " \n");

		} else if (result.getStatus() == ITestResult.SUCCESS) {

			test.pass(MarkupHelper.createLabel("Test Case " + ScriptName + " Status is PASSED:", ExtentColor.GREEN));
			test.pass("This Test Case PASSED:: ", MediaEntityBuilder
					.createScreenCaptureFromBase64String(ScreenshotLib.getScreenshotExtent(driver.get())).build());
			logger.info(ScriptName + " Script is passed and Report generated:");

			Reporter.log(ScriptName + " Script is passed and Report generated:", true);

		} else if (result.getStatus() == ITestResult.SKIP) {
			test.skip(MarkupHelper.createLabel("Test Case " + ScriptName + " Status is SKIPED:", ExtentColor.ORANGE));

			test.skip("This Test Case SKIPED:: ", MediaEntityBuilder
					.createScreenCaptureFromBase64String(ScreenshotLib.getScreenshotExtent(driver.get())).build());
			logger.info(ScriptName + " Script is skiped :");
			Reporter.log(ScriptName + " Script is skiped :", true);
			test.skip("<details>" + "<summary>" + "<b>" + "<font color=" + "yellow>" + "Exception Occured:Click to see"
					+ "</font>" + "</b >" + "</summary>" + ScriptName.replaceAll(",", "<br>") + "</details>" + " \n");
			test.skip(result.getThrowable());
		}
		   
		
	}

	@AfterTest
	public void after_test_setup() {
		driver.get().quit();

		logger.info("--------------- Script End-----------");
	}

	@AfterSuite
	public void aftersuitsetup(ITestContext context) {
		extent.flush();
		logger.info("Extent Report Generated and Mailed ");
		EmailTemp.main(context.getSuite().getName().toString());

	}
	
}

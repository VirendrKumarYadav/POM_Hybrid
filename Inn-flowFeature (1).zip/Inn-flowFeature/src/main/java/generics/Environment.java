package generics;

import org.aeonbits.owner.Config;
import org.aeonbits.owner.Config.Sources;




@Sources({"classpath:${env}.properties"})
public interface Environment extends Config{

	String downloadPath();
	String screenshotpath();
	String reportPath();
    String url();
    String username();
    String password();
    String TC_SheetPath();
    String gmail_Username();
    String gmailPassword();
    String To();
    String from();

    @Key("db.hosturl")
    String getDBHosturl();

     @Key("db.username")
    String getDBUsername();

    @Key("db.password")
    String getDBPassword();
	
}

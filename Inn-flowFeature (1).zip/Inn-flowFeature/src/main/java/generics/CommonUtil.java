package generics;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.Format;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;

public class CommonUtil {
	/**********************************
	 * -Date And Time-
	 * 
	 *******************************************/

	// -----------------Date And Time-----------------\\
	public Date getTime(long millis) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTimeInMillis(millis);
		return calendar.getTime();

	}
	
	public String getSimpleDateTimeFormate() {
		Format timestamp = new SimpleDateFormat("yyyy_MM_dd__hh_mm_ss");
		Date date = new Date();
		String dat = timestamp.format(date);
		return dat;
	}

	public String getSimpleDateWithoutTime() {
		Format sdf = new SimpleDateFormat("MM/dd/yy");
		Date dateWithoutTime = null;
		try {
			dateWithoutTime = (Date) sdf.parseObject(sdf.format(new Date()));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return dateWithoutTime.toString();
	}

	public static String getCurrentDate_MM_dd_yy() {
		Format f = new SimpleDateFormat("MM/dd/yy");
		String date = f.format(new Date());
		return date;

	}

	public String getCurrentDate_Day_dd() {
		Format f = new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss z");
		String date = f.format(new Date());
		System.out.println(date);
		return date;
	}

	public String getDayFormate(String date) {
		String dat[] = date.split(" ");
		if (dat[1].contains("01")) {
			dat[1] = "1";
		} else if (dat[1].contains("02")) {
			dat[1] = "2";

		} else if (dat[1].contains("03")) {
			dat[1] = "3";

		} else if (dat[1].contains("04")) {
			dat[1] = "4";

		} else if (dat[1].contains("05")) {
			dat[1] = "5";

		} else if (dat[1].contains("06")) {
			dat[1] = "6";

		} else if (dat[1].contains("07")) {
			dat[1] = "7";

		} else if (dat[1].contains("08")) {
			dat[1] = "8";

		} else if (dat[1].contains("09")) {
			dat[1] = "9";
		}
		date = dat[0] + " " + dat[1] + " " + dat[2];
		return date;
	}

	public String getPreviousToCurrentDate_MM_dd_yy(int NoOfDaysToPrevious) {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -NoOfDaysToPrevious);

		Format s = new SimpleDateFormat("MM/dd/yy");
		String result = s.format(new Date(cal.getTimeInMillis()));
		return result;
	}

	public String getNextToCurrentDate_MM_dd_yy(int NoOfDaysToPrevious) {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, +NoOfDaysToPrevious);

		Format s = new SimpleDateFormat("MM/dd/yy");
		String result = s.format(new Date(cal.getTimeInMillis()));
		return result;
	}

	public String getNextMonthToCurrentDate_MM_dd_yy(int NoOfMonthToNext) {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MONTH, NoOfMonthToNext);

		Format s = new SimpleDateFormat("MM/dd/yy");
		String result = s.format(new Date(cal.getTimeInMillis()));
		return result;
	}
	
	/*********************************************
	 * Properties File
	 *******************************************************/
	/**
	 * Load the Properties file By using given data on master.propperties
	 * 
	 * @throws IOException
	 */
	 static String flPath = System.getProperty("user.dir")+"/src/test/resources/Master.properties";
		static File file;
		static FileInputStream fis;
		static Properties propObj;

		private static Properties loadConfig(String filePath) {
			flPath = filePath;
			file = new File(filePath);

			try {
				fis = new FileInputStream(file);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			propObj = new Properties();
			try {
				propObj.load(fis);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return propObj;
		}

		public static String getPropVal(String keyname) {
			if (propObj == null) {
				loadConfig(flPath);
			}

			String propVal = propObj.getProperty(keyname);
			return propVal;
		}

		public void setProp(String key, String value) {
			if (propObj == null) {
				loadConfig(flPath);
			}
			propObj.setProperty(key, value);
		}

}

package generics;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import com.google.common.io.Files;

public class ScreenshotLib extends TestBase{

	
	/**
	 * SnapShot of the given details By using given
	 * 
	 * @throws IOException in File png
	 */
	public String takeSnapshot(WebDriver driver, String string) throws IOException {
		String screenshotPath = System.getProperty("user.dir") + "/Screenshot/" + string + ".png";
		EventFiringWebDriver efw = new EventFiringWebDriver(driver);

		TakesScreenshot ts = (TakesScreenshot) efw;
		File srcFile = ts.getScreenshotAs(OutputType.FILE);
		File destFile = new File(screenshotPath);

		try {
			FileUtils.copyFile(srcFile, destFile);

		} catch (IOException e) {
			e.printStackTrace();
		}

		return screenshotPath;

	}

	 public static String getScreenshotExtent(WebDriver driver) {
	        String Base64StringofScreenshot = "";
	        File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	        byte[] fileContent;
	        try {
	            fileContent = FileUtils.readFileToByteArray(src);
	            Base64StringofScreenshot = "data:image/png;base64," + Base64.getEncoder().encodeToString(fileContent);
	        } catch(IOException e) {
	            e.printStackTrace();
	        }
	        return Base64StringofScreenshot;
	    }
	/**
	 * SnapShot of the given details By using given
	 * 
	 * @throws IOException in file Base64
	 */
	public  String takeSnapshotAsBase64(WebDriver driver) throws IOException {
		Format timestamp = new SimpleDateFormat("MM-dd-yyyy");
		Date date = new Date();
		String dat = timestamp.format(date);
		String da = dat.replace("-", "_");

		String screenshotPath = System.getProperty("user.dir") + "\\src\\test\\resources\\Reports\\snapshot\\" + da + ".png";
		File srcFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

		try {
			Files.copy(srcFile, new File(screenshotPath));
		} catch (IOException e) {
//			threadExTest.get().log(Status.INFO, "Unable to log screenshot");
			e.printStackTrace();
		}

//		threadExTest.get().log(Status.PASS, " takeSnapshot is Applied sucessfully ");
		byte[] base64_Img = IOUtils.toByteArray(new FileInputStream(screenshotPath));
		return Base64.getEncoder().encodeToString(base64_Img);
	}

	/**
	 * 
	 */
	
	public static String takescreenshot( String ScriptName)
	{
		
//		String timestamp = new SimpleDateFormat("_yyyy_MM_dd__hh_mm_ss").format(new Date());

		String screenshotPath= System.getProperty("user.dir")+"/Reports/snapshot/"+ScriptName+ getCurrentDateTime()+".png";
		EventFiringWebDriver efw = new EventFiringWebDriver(driver.get());
		File srcFile = efw.getScreenshotAs(OutputType.FILE);
		File destFile = new File(screenshotPath);
		delete_file(5);
		try
		{
			FileUtils.copyFile(srcFile, destFile);
		
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}

		return screenshotPath;
	}
	
	
	public static void delete_file(int daysBack) {
		File dir = new File(System.getProperty("user.dir")+"/Reports/snapshot/");
		File[] files = dir.listFiles();
//		Calendar cal = Calendar.getInstance();  
//		 cal.add(Calendar.DAY_OF_MONTH, daysBack * -1);  
//		 long purgeTime = cal.getTimeInMillis(); 
	    long purgeTime = System.currentTimeMillis() - (daysBack * 24 * 60 * 60 * 1000);

		 
		for (File file : files) {
			if (file.exists()) {
				if (file.lastModified()<purgeTime) {
					file.delete();
					 if(!file.delete()) {
			                System.err.println("Unable to delete file: " + file);
			            }
				}
				
				
				
			}
		}
	}
	
	public static String getCurrentDateTime()
	{
		String timestamp = new SimpleDateFormat("_dd_MM_yyyy_hh_mm_ss").format(new Date());
		return timestamp;
		
	}
	
	/**
	 * By Base 64
	 * Library
	 *  
	 */
	
	
	
	
	
}

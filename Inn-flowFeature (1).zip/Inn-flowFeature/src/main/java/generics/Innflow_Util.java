package generics;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class Innflow_Util extends TestBase{

	
	public Innflow_Util(WebDriver driver) {
		PageFactory.initElements(driver, Innflow_Util.this);
	}
	
	@FindBy(xpath="//button[@id='dropdown-hid']")public  WebElement EHID_dd;
	@FindBy(xpath="//input[@placeholder='Filter EHIDs']")private static WebElement EHID_in;
	@FindBy(xpath="//a[@class='dropdown-item']/div")private static WebElement EHID_slc_btn;
	@FindBy(xpath="//td[@class='accountBalance text-right']/div")private static WebElement ac_ballance_txt;
	
	
	
	
	
	public  void clickOnEHID_ByEHID(String EHID) {
		WaitStatement.holdOn(4);
		try {
			WaitStatement.eWaitForVisible(20, ac_ballance_txt);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		if(EHID_dd.isEnabled()) {
			EHID_dd.click();
		}else {
			Assert.assertEquals(EHID_dd.isEnabled(), false);
		}
	
		try {
			WaitStatement.eWaitForVisible(20, EHID_in);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(EHID_in.isEnabled()) {
			EHID_in.sendKeys(EHID);
		}else {
			Assert.assertEquals(EHID_in.isEnabled(), false);
		}
		
		EHID_slc_btn.click();
	}

	public void verifyColour(WebElement we,String expClr) {
		 String s = we.getCssValue("color");
	      String c = Color.fromString(s).asHex();
	      System.out.println("Hex code for color:" + c);
	      if(c.equals(expClr)) {
	    	  logger.info("you colour matched Hex code "+c);
	      }else {
	    	  Assert.assertEquals(c, expClr);
	    	  logger.info("you colour is not matched Hex code "+c);
	     }
	}
	
	public void verifyFontSize(WebElement we,String expF) {
		 String actF=we .getCssValue("font-size");
		  if(actF.equals(expF)) {
	    	  logger.info("you colour matched Hex code "+actF);
	      }else {
	    	  Assert.assertEquals(actF, expF);
	    	  logger.info("you colour is not matched Hex code "+actF);
	      }
	}
	
	public void verifyText(WebElement we,String expText) {
		 String acText=we .getText();
		  if(acText.equals(expText)) {
	    	  logger.info("you colour matched Hex code "+acText);
	      }else {
	    	  Assert.assertEquals(acText, expText);
	    	  logger.info("you colour is not matched Hex code "+acText);
	      }
	}
}

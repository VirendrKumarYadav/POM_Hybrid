package generics;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.aeonbits.owner.ConfigFactory;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.ResultSetMetaData;
import com.mysql.jdbc.Statement;

public class DBLib extends TestBase{

 	 Environment configENV = ConfigFactory.create(Environment.class);
 	 
// 	public String getReportingLevelName(int level) throws SQLException, Exception{
//   	String uid = Database_SelectQuery_Execution("select Tanent from UserDetails where username='"+configENV.username()+"';","uid");
//		String lName = Database_SelectQuery_Execution("select levelName from reportingLevels where uid='"+uid+"' and levelNo='"+level+"';","levelName");
//		return lName;
//	}

   public  String Database_SelectQuery_Execution( String query,String column) throws SQLException, Exception 
	{
   	try{
		Class.forName("com.mysql.jdbc.Driver");
		logger.info("Driver Loaded");

		Connection con = (Connection) java.sql.DriverManager.getConnection(configENV.getDBHosturl(),
				configENV.getDBUsername(), configENV.getDBPassword());
		logger.info("connection establish");
		Statement stmt = (Statement) con.createStatement();
		String re = null;
		logger.info(query);
		ResultSet r = stmt.executeQuery(query);
		while (r.next()) {
			re = r.getString(column);
		}
		return re;
   	}catch (Exception e) {
			// TODO: handle exception
		}
		return column;
		
	}
   public List<String> Database_SelectQuery_ReturnArrayList(String query, String wherecolum) throws SQLException, Exception
   {
   	Class.forName("com.mysql.jdbc.Driver");
   	logger.info("Driver Loaded");
		 Connection	con = (Connection) java.sql.DriverManager.getConnection(configENV.getDBHosturl(), configENV.getDBUsername(), configENV.getDBPassword());		
		 logger.info("conection establish");
   	Statement stmt = (Statement) con.createStatement();					
   	
   	List<String> record= new ArrayList<>() ;
   	logger.info(query);
   	ResultSet r=stmt.executeQuery(query);
   	while(r.next())
   	{
   		String re=r.getString(wherecolum);
   		logger.info(re);
   		record.add(re);

   	}
   	return record;		
   }
   
   public ArrayList<String> Database_SelectQuery_ReturnArrayListString(String query,String column) throws SQLException, Exception
   {
		
   	Class.forName("com.mysql.jdbc.Driver");
   	logger.info("Driver Loaded");
		 Connection	con = (Connection) java.sql.DriverManager.getConnection(configENV.getDBHosturl(), configENV.getDBUsername(), configENV.getDBPassword());		
		 logger.info("coonection establish");
   	Statement stmt = (Statement) con.createStatement();					
   	
   	ArrayList<String> record= new ArrayList<>() ;
   	logger.info(query);
   	ResultSet r=stmt.executeQuery(query);
   	while(r.next())
   	{
   		String re=r.getString(column);
   		logger.info(re);
   		record.add(re);

   	}
   	return record;		
   }
   
   
   
   public void Database_UpadteQuery_Execution(String query) throws SQLException, Exception 
   {
      try{
		Class.forName("com.mysql.jdbc.Driver");
		logger.info("Driver Loaded");
		
		 Connection	con = (Connection) java.sql.DriverManager.getConnection(configENV.getDBHosturl(), configENV.getDBUsername(), configENV.getDBPassword());		
		 logger.info("connection establish");
		
		Statement stmt = (Statement) con.createStatement();
		logger.info(query);
		stmt.executeUpdate(query);
      }catch (Exception e) {
		// TODO: handle exception
	}
		
	}
   
   
   public ArrayList<Map> DatabaseQuery_ReturnMapObject(String query) throws SQLException, Exception
   {
   Class.forName("com.mysql.jdbc.Driver");

   Map<String, String> h = new HashMap<>();
   logger.info("Driver Loaded with Production Server");

   Connection con=    (Connection) java.sql.DriverManager.getConnection(configENV.getDBHosturl(), configENV.getDBUsername(), configENV.getDBPassword());
   logger.info("connection established with Production Server");
   Statement stmt = (Statement) con.createStatement();

   ArrayList<Map> record= new ArrayList<Map>(20) ;
   logger.info(query);
   ResultSet r=stmt.executeQuery(query);
   ResultSetMetaData rsmd = (ResultSetMetaData) r.getMetaData();
   int columnsNumber = rsmd.getColumnCount();

   while(r.next())
   {  
   Map<String, String> task=new HashMap<String, String>();
   for(int i = 1; i <=columnsNumber;i++) {
   String re=r.getString(i);
   task.put(rsmd.getColumnName(i),re);
   }
   record.add(task);
   }

   return record;

   }
}
